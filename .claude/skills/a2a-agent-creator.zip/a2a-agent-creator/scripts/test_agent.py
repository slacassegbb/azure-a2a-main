#!/usr/bin/env python3
"""
A2A Agent Test Runner

Tests a newly scaffolded agent by:
1. Finding Azure credentials from a sibling agent's .env
2. Creating .env for the new agent
3. Installing dependencies
4. Running syntax checks
5. Starting the server
6. Testing /health and /.well-known/agent.json endpoints
7. Reporting results

Usage:
    test_agent.py <agent-directory> [--port PORT]

Examples:
    test_agent.py remote_agents/azurefoundry_GitHub
    test_agent.py remote_agents/azurefoundry_GitHub --port 9035
"""

import sys
import os
import subprocess
import time
import json
import ast
import shutil
import signal
from pathlib import Path


def find_azure_credentials(agent_dir: Path) -> dict:
    """Find Azure credentials from sibling agents or project root."""
    creds = {}
    needed_keys = [
        "AZURE_AI_FOUNDRY_PROJECT_ENDPOINT",
        "AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME",
    ]

    # Search locations in priority order
    search_paths = []

    # 1. Sibling agent .env files
    remote_agents_dir = agent_dir.parent
    if remote_agents_dir.exists():
        for sibling in sorted(remote_agents_dir.iterdir()):
            if sibling.is_dir() and sibling != agent_dir:
                env_file = sibling / ".env"
                if env_file.exists():
                    search_paths.append(env_file)

    # 2. Project root .env
    project_root = remote_agents_dir.parent
    root_env = project_root / ".env"
    if root_env.exists():
        search_paths.append(root_env)

    for env_file in search_paths:
        try:
            with open(env_file) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" in line:
                        key, _, value = line.partition("=")
                        key = key.strip()
                        value = value.strip().strip('"').strip("'")
                        if key in needed_keys and value and key not in creds:
                            creds[key] = value
        except Exception:
            continue

        if all(k in creds for k in needed_keys):
            print(f"  Found credentials in: {env_file}")
            break

    return creds


def create_env_file(agent_dir: Path, port: int) -> bool:
    """Create .env file with discovered credentials."""
    env_file = agent_dir / ".env"

    if env_file.exists():
        print(f"  .env already exists, checking credentials...")
        creds = {}
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    if value:
                        creds[key] = value

        if "AZURE_AI_FOUNDRY_PROJECT_ENDPOINT" in creds:
            print(f"  Credentials present in existing .env")
            return True

    print(f"  Searching for Azure credentials in sibling agents...")
    creds = find_azure_credentials(agent_dir)

    if "AZURE_AI_FOUNDRY_PROJECT_ENDPOINT" not in creds:
        print(f"  ERROR: Could not find AZURE_AI_FOUNDRY_PROJECT_ENDPOINT")
        print(f"  Searched sibling agents and project root .env files")
        return False

    if "AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME" not in creds:
        creds["AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME"] = "gpt-4o"

    # Read .env.example for any extra keys
    extra_keys = {}
    env_example = agent_dir / ".env.example"
    if env_example.exists():
        with open(env_example) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    if key not in creds:
                        extra_keys[key] = value

    # Write .env
    with open(env_file, "w") as f:
        for key, value in creds.items():
            f.write(f'{key}="{value}"\n')
        f.write(f"A2A_ENDPOINT=localhost\n")
        f.write(f"A2A_PORT={port}\n")
        f.write(f"A2A_HOST=http://localhost:12000\n")
        f.write(f"LOG_LEVEL=INFO\n")
        for key, value in extra_keys.items():
            if key not in ("A2A_ENDPOINT", "A2A_PORT", "A2A_HOST", "LOG_LEVEL"):
                f.write(f"{key}={value}\n")

    print(f"  Created .env with Azure credentials")
    return True


def check_syntax(agent_dir: Path) -> bool:
    """Check Python syntax of all agent files."""
    py_files = ["__main__.py", "foundry_agent.py", "foundry_agent_executor.py"]
    all_ok = True

    for fname in py_files:
        fpath = agent_dir / fname
        if not fpath.exists():
            print(f"  MISSING: {fname}")
            all_ok = False
            continue
        try:
            with open(fpath) as f:
                ast.parse(f.read())
            print(f"  {fname}: OK")
        except SyntaxError as e:
            print(f"  {fname}: SYNTAX ERROR - {e}")
            all_ok = False

    return all_ok


def install_dependencies(agent_dir: Path) -> bool:
    """Install dependencies using uv."""
    pyproject = agent_dir / "pyproject.toml"
    if not pyproject.exists():
        print(f"  ERROR: pyproject.toml not found")
        return False

    venv = agent_dir / ".venv"
    if venv.exists():
        print(f"  .venv exists, skipping install")
        return True

    try:
        result = subprocess.run(
            ["uv", "sync"],
            cwd=str(agent_dir),
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            print(f"  Dependencies installed")
            return True
        else:
            # Try alternative install
            result = subprocess.run(
                ["uv", "pip", "install", "-e", "."],
                cwd=str(agent_dir),
                capture_output=True,
                text=True,
                timeout=120,
                env={**os.environ, "VIRTUAL_ENV": str(venv)},
            )
            if result.returncode == 0:
                print(f"  Dependencies installed (pip fallback)")
                return True
            print(f"  ERROR: {result.stderr[:300]}")
            return False
    except FileNotFoundError:
        print(f"  ERROR: uv not found. Install with: curl -LsSf https://astral.sh/uv/install.sh | sh")
        return False
    except subprocess.TimeoutExpired:
        print(f"  ERROR: Dependency install timed out")
        return False


def test_imports(agent_dir: Path) -> bool:
    """Test that all imports resolve."""
    result = subprocess.run(
        [
            "uv", "run", "python3", "-c",
            "from foundry_agent_executor import FoundryAgentExecutor, create_foundry_agent_executor; "
            "from a2a.types import AgentCard, AgentSkill; "
            "print('imports OK')"
        ],
        cwd=str(agent_dir),
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode == 0 and "imports OK" in result.stdout:
        print(f"  All imports resolved")
        return True
    else:
        print(f"  Import error: {result.stderr[:300]}")
        return False


def test_server(agent_dir: Path, port: int) -> dict:
    """Start server, test endpoints, return results."""
    results = {"health": False, "agent_card": False, "card_data": None}

    # Start server in background
    proc = subprocess.Popen(
        ["uv", "run", ".", "--port", str(port)],
        cwd=str(agent_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    try:
        # Wait for server to start
        print(f"  Waiting for server on port {port}...")
        import urllib.request
        import urllib.error

        started = False
        for i in range(20):
            time.sleep(1)
            try:
                req = urllib.request.urlopen(f"http://localhost:{port}/health", timeout=3)
                if req.status == 200:
                    health_text = req.read().decode()
                    print(f"  /health: 200 - {health_text}")
                    results["health"] = True
                    started = True
                    break
            except (urllib.error.URLError, ConnectionRefusedError, OSError):
                if i % 5 == 4:
                    print(f"  Still waiting... ({i+1}s)")
                continue

        if not started:
            print(f"  ERROR: Server did not start within 20s")
            # Capture output for debugging
            proc.terminate()
            try:
                out, _ = proc.communicate(timeout=5)
                if out:
                    print(f"  Server output:\n{out[-500:]}")
            except Exception:
                pass
            return results

        # Test agent card
        try:
            req = urllib.request.urlopen(
                f"http://localhost:{port}/.well-known/agent.json", timeout=5
            )
            if req.status == 200:
                card = json.loads(req.read().decode())
                results["agent_card"] = True
                results["card_data"] = card
                print(f"  /agent.json: 200")
                print(f"    Name: {card.get('name')}")
                print(f"    Skills: {len(card.get('skills', []))}")
                for s in card.get("skills", []):
                    print(f"      - {s.get('name')}")
                print(f"    Streaming: {card.get('capabilities', {}).get('streaming')}")
        except Exception as e:
            print(f"  /agent.json: ERROR - {e}")

    finally:
        # Shutdown server
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        print(f"  Server shut down")

    return results


def main():
    if len(sys.argv) < 2:
        print("Usage: test_agent.py <agent-directory> [--port PORT]")
        sys.exit(1)

    agent_dir = Path(sys.argv[1]).resolve()
    port = 9035  # default

    # Parse --port
    if "--port" in sys.argv:
        idx = sys.argv.index("--port")
        if idx + 1 < len(sys.argv):
            port = int(sys.argv[idx + 1])

    print(f"Testing agent: {agent_dir.name}")
    print(f"Port: {port}")
    print()

    # Step 1: Check files exist
    print("[1/6] Checking file structure...")
    required = [
        "__main__.py", "foundry_agent.py", "foundry_agent_executor.py",
        "pyproject.toml", "Dockerfile", ".env.example", ".dockerignore",
        "utils/__init__.py", "utils/self_registration.py",
    ]
    missing = [f for f in required if not (agent_dir / f).exists()]
    if missing:
        print(f"  MISSING FILES: {missing}")
        sys.exit(1)
    print(f"  All {len(required)} required files present")

    # Step 2: Syntax check
    print("\n[2/6] Checking Python syntax...")
    if not check_syntax(agent_dir):
        sys.exit(1)

    # Step 3: Create .env
    print("\n[3/6] Configuring credentials...")
    if not create_env_file(agent_dir, port):
        sys.exit(1)

    # Step 4: Install dependencies
    print("\n[4/6] Installing dependencies...")
    if not install_dependencies(agent_dir):
        sys.exit(1)

    # Step 5: Test imports
    print("\n[5/6] Testing imports...")
    if not test_imports(agent_dir):
        sys.exit(1)

    # Step 6: Test server
    print(f"\n[6/6] Testing server endpoints...")
    results = test_server(agent_dir, port)

    # Summary
    print("\n" + "=" * 50)
    print("TEST RESULTS")
    print("=" * 50)

    checks = [
        ("File structure", True),
        ("Python syntax", True),
        ("Credentials configured", True),
        ("Dependencies installed", True),
        ("Imports resolved", True),
        ("Health endpoint", results["health"]),
        ("Agent card endpoint", results["agent_card"]),
    ]

    all_passed = True
    for name, passed in checks:
        status = "PASS" if passed else "FAIL"
        print(f"  {status}: {name}")
        if not passed:
            all_passed = False

    if results.get("card_data"):
        card = results["card_data"]
        print(f"\n  Agent: {card.get('name')}")
        print(f"  Skills: {len(card.get('skills', []))}")
        print(f"  URL: {card.get('url')}")

    print()
    if all_passed:
        print("ALL TESTS PASSED")
        sys.exit(0)
    else:
        print("SOME TESTS FAILED")
        sys.exit(1)


if __name__ == "__main__":
    main()
